Blue Vinyl Fonts
(c) 2009 All Rights Reserved
bvfonts.com

The Freeware Font(s) included in this pack were created by Jess Latham. I am inspired by my uncontrolable love for music and graphic design. All fonts are original works. 

Please do not include this font on any CD-ROM compilations. This font is not to be resold or remarketed. This font is free to use in any private and commercial manner. If you plan to use this font commercially and would like to say thanks for the free font you can purchase a pay font from bvfonts.com and I would be very grateful.

Please read the legal notice below. Basically what it is saying is that I'm human and although I work very hard to make fonts that work well, I'm not perfect.

NO WARRANTIES. Blue Vinyl Fonts expressly disclaims any warranty for this SOFTWARE PRODUCT. This SOFTWARE PRODUCT and any related documentation is provided "as is" without warranty of any kind, either express or implied, including, without limitation, the implied warranties or merchantability, fitness for a particular purpose, or noninfringement. The entire risk arising out of use or performance of the SOFTWARE PRODUCT remains with you.

NO LIABILITY FOR CONSEQUENTIAL DAMAGES. In no event shall Blue Vinyl Fonts be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or any other pecuniary loss) arising out of the use of or inability to use this product, even if Blue Vinyl Fonts has been advised of the possibility of such damages.

In some states the above limitation may not apply to you.

UNDER NO CIRCUMSTANCES SHOULD THESE FONTS BE USED IN A SITUATION THAT COULD ENDANGER LIFE OR THE ENVIROMENT. FOR INSTANCE AIRPLANE NAVIGATION, SAFETY SIGNS, etc. 

EDUCATIONAL PURPOSES: If this font is used in an educational situation it is up to you the user or teacher to confirm that they are useful and you take full responsibility for it's use.

You agree to comply with all laws restricting the exportation of software or technology in the use of this software.

Blue Vinyl Fonts reserves the right to make changes to this license at any time.

Have questions? Please visit bvfonts.com and click the email me link. I love hearing from you!

- Jess Latham
Blue Vinyl Fonts 
